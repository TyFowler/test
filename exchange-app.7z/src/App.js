import { injected } from "./components/wallet/connectors";
import { useWeb3React } from "@web3-react/core";
import { Web3ReactProvider } from "@web3-react/core";
import {Web3Provider} from "@ethersproject/providers";
import React from 'react';

export default function App() {

  const InteractiveArea = () => {
    const {active, account, activate, deactivate} = useWeb3React();

    console.log(activate);

    return (
      <div>
        <button onClick={() => {activate(injected)}}>Connect Wallet</button>
        {active ? (<div>connected: {account}</div>): (<div>Not connected</div>)}
        <button onClick={() => {deactivate()}}>Disconnect Wallet</button>
      </div>
    )
  }
  
  

  function getLibraryf(provider) {
    const library = new Web3Provider(provider);
    library.pollingInterval = 12000;
    return library;
  }

  return (
    <Web3ReactProvider getLibrary={getLibraryf}>
      <InteractiveArea />
    </Web3ReactProvider>
  )
}